/* Resolve the saved accent before the main stylesheet paints. Keep this file
   tiny and synchronous so first-frame colors match the persisted preference. */
(function bootstrapInitialThemeAccent() {
  var accent = '#1765f5';
  try {
    var raw = localStorage.getItem('sumaire_settings_master');
    var settings = raw ? JSON.parse(raw) : null;
    if (typeof settings?.accentColor === 'string' && /^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/.test(settings.accentColor)) {
      accent = settings.accentColor;
    }
  } catch (_) { /* Storage may be blocked; use the clean blue default. */ }
  document.documentElement.style.setProperty('--sa-initial-accent', accent);
})();
