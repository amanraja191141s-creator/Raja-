# SA Calculator v98.10 workflow regression fix

## Root cause
The `android-build-readiness.test.js` test asserted exact text from an older workflow implementation. The current workflow uses a different but valid source-root locator and ZIP extraction flow, so the stale text assertion failed even though source detection, source validation, dependency installation, and JavaScript syntax validation passed in GitHub Actions.

## Change
- Updated the workflow readiness regression test to validate supported locator IDs (`locate` or `source`), matching `working-directory` output, required npm/Capacitor/Gradle/artifact stages, and explicit missing/ambiguous package diagnostics.
- No calculator runtime logic or UI files were changed.

## Local verification
- `npm test`: 150 passed, 0 failed.
- `npm run build:web`: passed; 8 required source assets verified and copied to `www/`.
- `node --check` for application, localization, currency names, theme bootstrap, server, service worker, and web-build script: passed.
- ZIP integrity: verified after packaging.

## Not claimed
A GitHub-hosted Android APK build has not yet been run with this patched archive. Gradle/APK compilation and artifact upload remain to be verified by the next GitHub Actions run.
