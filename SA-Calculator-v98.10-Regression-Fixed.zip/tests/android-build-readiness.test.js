const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.join(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('Capacitor Android wrapper is configured for a local offline web bundle', () => {
  const config = JSON.parse(read('capacitor.config.json'));
  assert.equal(config.appId, 'com.sacalculator.app');
  assert.equal(config.appName, 'SA Calculator');
  assert.equal(config.webDir, 'www');
  assert.equal(config.server.androidScheme, 'https');
  assert.equal(config.android.allowMixedContent, false);
});

test('Android build workflow locates or extracts the app root before running npm', () => {
  const workflow = read('.github/workflows/android-apk.yml');
  const hasLocatorId = /id: (locate|source)\b/.test(workflow);
  assert.ok(hasLocatorId, 'Workflow must expose a project-root output before npm runs');
  assert.match(workflow, /find .*package\.json|package\.json/);
  assert.match(workflow, /working-directory: \$\{\{ steps\.(locate|source)\.outputs\.app_dir \}\}/);

  for (const expected of [
    'npm install --no-audit --no-fund',
    'npm test',
    'npm run build:web',
    'npx cap add android',
    'npx cap sync android',
    'assembleDebug',
    'actions/upload-artifact@v4',
    'app-debug.apk'
  ]) {
    assert.ok(workflow.includes(expected), `Missing Android build configuration: ${expected}`);
  }

  assert.match(workflow, /Multiple package\.json files found|Expected exactly one application package\.json/);
  assert.match(workflow, /package\.json (was not found|missing)|No package\.json|Expected exactly one application package\.json/);
});

test('Android web bundle builder verifies all runtime assets before copying', () => {
  const script = read('scripts/prepare-android-web.mjs');
  for (const asset of ['index.html', 'assets/css/app.css', 'assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png', 'service-worker.js']) {
    assert.ok(script.includes(asset), `Missing required web asset: ${asset}`);
  }
});


test('Android web bundle contains the registered service worker and its precache dependencies', () => {
  const result = spawnSync(process.execPath, ['scripts/prepare-android-web.mjs'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const out = path.join(root, 'www');
  assert.equal(fs.existsSync(path.join(out, 'service-worker.js')), true, 'service-worker.js must be shipped beside index.html');
  const sw = fs.readFileSync(path.join(out, 'service-worker.js'), 'utf8');
  const list = sw.match(/const ASSETS=\[(.*?)\];/s);
  assert.ok(list, 'bundled service worker must contain its precache list');
  for (const [, asset] of list[1].matchAll(/'([^']+)'/g)) {
    const local = asset === './' ? 'index.html' : asset.replace(/^\.\//, '');
    assert.equal(fs.existsSync(path.join(out, local)), true, `bundled precache asset missing: ${asset}`);
  }
});
